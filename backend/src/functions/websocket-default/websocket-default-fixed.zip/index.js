const { 
  ApiGatewayManagementApiClient, 
  PostToConnectionCommand 
} = require('@aws-sdk/client-apigatewaymanagementapi');
const { DynamoDBClient } = require('@aws-sdk/client-dynamodb');
const { DynamoDBDocumentClient, PutCommand, ScanCommand, DeleteCommand } = require('@aws-sdk/lib-dynamodb');

exports.handler = async (event) => {
  console.log('WebSocket Default Handler started');
  console.log('Full event received:', JSON.stringify(event, null, 2));
  
  try {
    // Defensive access to event properties
    const connectionId = event.requestContext?.connectionId;
    const routeKey = event.requestContext?.routeKey;
    const body = event.body;
    const apiId = event.requestContext?.apiId;
    
    console.log(`Extracted values: connectionId=${connectionId}, routeKey=${routeKey}, apiId=${apiId}`);
    
    if (!connectionId) {
      console.error('Missing connectionId in event.requestContext');
      return {
        statusCode: 400,
        body: JSON.stringify({ error: 'Missing connectionId' })
      };
    }
    
    console.log(`WebSocket message: ${connectionId}, route: ${routeKey}, body: ${body}`);

    // Initialize API Gateway Management API client
    const defaultApiId = 'lwk0wf6rpl'; // WebSocket API ID from stack output
    const effectiveApiId = apiId || defaultApiId;
    
    const apiGatewayClient = new ApiGatewayManagementApiClient({
      endpoint: `https://${effectiveApiId}.execute-api.us-east-1.amazonaws.com/dev`
    });

    // Initialize DynamoDB client
    const dynamoClient = new DynamoDBClient({ region: 'us-east-1' });
    const docClient = DynamoDBDocumentClient.from(dynamoClient);
    const SUBSCRIPTIONS_TABLE = process.env.WEBSOCKET_SUBSCRIPTIONS_TABLE || 'WizzUser_websocket_subscriptions_dev';

    // Parse the message if it exists
    let message;
    if (body) {
      try {
        message = JSON.parse(body);
        console.log('Parsed message:', JSON.stringify(message));
      } catch (e) {
        console.log('Failed to parse message body:', body);
        message = { type: 'unknown', body };
      }
    }
    
    // Handle different message types (support both 'type' and 'action' fields)
    const messageType = message?.type || message?.action;
    if (messageType) {
      switch (messageType) {
            case 'subscribe':
            case 'subscribe_business_status':
              const businessId = message.business_id || message.businessId;
              const userId = message.user_id || message.userId;
              console.log(`Subscribing connection ${connectionId} to business status ${businessId} for user ${userId}`);
              
              // Store this subscription in DynamoDB
              try {
                const subscriptionItem = {
                  subscriptionId: `${connectionId}_${businessId}`, // Primary key
                  connectionId: connectionId,
                  businessId: businessId,
                  userId: userId,
                  subscriptionType: 'business_status',
                  timestamp: new Date().toISOString(),
                  ttl: Math.floor(Date.now() / 1000) + (24 * 60 * 60) // 24 hours TTL
                };
                
                await docClient.send(new PutCommand({
                  TableName: SUBSCRIPTIONS_TABLE,
                  Item: subscriptionItem
                }));
                
                console.log(`Stored business status subscription for ${connectionId} -> ${businessId}`);
              } catch (dbError) {
                console.error(`Failed to store subscription in DynamoDB:`, dbError);
              }
              
              // Send acknowledgment back to client
              try {
                const ackResponse = {
                  type: 'subscription_ack',
                  action: 'subscribe_business_status',
                  businessId: businessId,
                  timestamp: new Date().toISOString(),
                  connectionId: connectionId
                };
                
                const command = new PostToConnectionCommand({
                  ConnectionId: connectionId,
                  Data: JSON.stringify(ackResponse)
                });
                
                await apiGatewayClient.send(command);
                console.log(`Business status subscription acknowledgment sent to ${connectionId}`);
              } catch (ackError) {
                console.error(`Failed to send subscription ack to ${connectionId}:`, ackError);
              }
              break;

            case 'unsubscribe':
            case 'unsubscribe_business_status':
              const unsubBusinessId = message.business_id || message.businessId;
              console.log(`Unsubscribing connection ${connectionId} from business status ${unsubBusinessId}`);
              
              // Remove subscription from DynamoDB
              try {
                await docClient.send(new DeleteCommand({
                  TableName: SUBSCRIPTIONS_TABLE,
                  Key: {
                    subscriptionId: `${connectionId}_${unsubBusinessId}`
                  }
                }));
                console.log(`Removed business status subscription for ${connectionId} -> ${unsubBusinessId}`);
              } catch (dbError) {
                console.error(`Failed to remove subscription from DynamoDB:`, dbError);
              }
              break;

            case 'subscribe_order':
              const orderId = message.order_id || message.orderId;
              const orderUserId = message.user_id || message.userId;
              console.log(`Subscribing connection ${connectionId} to order ${orderId} for user ${orderUserId}`);
              // In a real implementation, you would store this subscription
              break;

            case 'unsubscribe_order':
              const unsubOrderId = message.order_id || message.orderId;
              console.log(`Unsubscribing connection ${connectionId} from order ${unsubOrderId}`);
              break;

            case 'BUSINESS_BUSY_STATUS_UPDATE':
              console.log(`Received business busy status update:`, message);
              const updateBusinessId = message.business_id || message.businessId;
              const isBusy = message.isBusy;
              const updateUserId = message.user_id || message.userId;
              
              if (updateBusinessId && typeof isBusy === 'boolean') {
                console.log(`Processing status update for business ${updateBusinessId}: isBusy=${isBusy}`);
                
                // Broadcast this update to all subscribed customers
                console.log(`Business ${updateBusinessId} status update processed: ${isBusy ? 'BUSY' : 'AVAILABLE'}`);
                
                // Create the broadcast message for customers
                const customerUpdateMessage = {
                  type: 'BUSINESS_STATUS_UPDATE',
                  businessId: updateBusinessId,
                  isBusy: isBusy,
                  status: isBusy ? 'BUSY' : 'AVAILABLE',
                  timestamp: new Date().toISOString()
                };
                
                console.log(`Would broadcast to customers: ${JSON.stringify(customerUpdateMessage)}`);
                
                // Query DynamoDB to find all customers subscribed to this business
                try {
                  console.log(`Querying subscriptions for business: ${updateBusinessId}`);
                  
                  // Use ScanCommand instead of QueryCommand since we don't have GSI yet
                  const scanParams = {
                    TableName: SUBSCRIPTIONS_TABLE,
                    FilterExpression: 'businessId = :businessId AND subscriptionType = :subType',
                    ExpressionAttributeValues: {
                      ':businessId': updateBusinessId,
                      ':subType': 'business_status'
                    }
                  };
                  
                  const result = await docClient.send(new ScanCommand(scanParams));
                  const subscriptions = result.Items || [];
                  
                  console.log(`Found ${subscriptions.length} subscriptions for business ${updateBusinessId}`);
                  
                  // Send the update to each subscribed customer
                  const broadcastPromises = subscriptions.map(async (subscription) => {
                    try {
                      const customerConnectionId = subscription.connectionId;
                      console.log(`Sending update to customer connection: ${customerConnectionId}`);
                      
                      const command = new PostToConnectionCommand({
                        ConnectionId: customerConnectionId,
                        Data: JSON.stringify(customerUpdateMessage)
                      });
                      
                      await apiGatewayClient.send(command);
                      console.log(`✅ Sent business status update to ${customerConnectionId}`);
                      return { success: true, connectionId: customerConnectionId };
                    } catch (sendError) {
                      console.error(`❌ Failed to send update to ${subscription.connectionId}:`, sendError);
                      
                      // If connection is stale, remove the subscription
                      if (sendError.name === 'GoneException') {
                        try {
                          await docClient.send(new DeleteCommand({
                            TableName: SUBSCRIPTIONS_TABLE,
                            Key: {
                              subscriptionId: `${subscription.connectionId}_${updateBusinessId}`
                            }
                          }));
                          console.log(`Removed stale subscription: ${subscription.connectionId}`);
                        } catch (deleteError) {
                          console.error(`Failed to remove stale subscription:`, deleteError);
                        }
                      }
                      return { success: false, connectionId: subscription.connectionId, error: sendError.message };
                    }
                  });
                  
                  const broadcastResults = await Promise.all(broadcastPromises);
                  const successCount = broadcastResults.filter((r) => r.success).length;
                  console.log(`📡 Broadcast complete: ${successCount}/${subscriptions.length} customers notified`);
                  
                } catch (queryError) {
                  console.error(`Failed to query subscriptions:`, queryError);
                  console.log(`Broadcasting business status update to subscribed customers failed due to query error`);
                }
                
                // Send acknowledgment back to the business app
                try {
                  const ackResponse = {
                    type: 'business_status_update_ack',
                    businessId: updateBusinessId,
                    isBusy: isBusy,
                    timestamp: new Date().toISOString(),
                    processed: true
                  };
                  
                  const command = new PostToConnectionCommand({
                    ConnectionId: connectionId,
                    Data: JSON.stringify(ackResponse)
                  });
                  
                  await apiGatewayClient.send(command);
                  console.log(`Business status update acknowledgment sent to ${connectionId}`);
                } catch (ackError) {
                  console.error(`Failed to send status update ack to ${connectionId}:`, ackError);
                }
              } else {
                console.error(`Invalid business status update message:`, message);
              }
              break;

            case 'REGISTER_CONNECTION':
            case 'register_connection':
              const merchantId = message.merchant_id || message.merchantId || message.businessId || message.business_id;
              const deviceInfo = message.device_info || message.deviceInfo || {};
              console.log(`Registering merchant connection ${connectionId} for merchant ${merchantId}`);
              
              // Store merchant connection in DynamoDB connections table
              try {
                const connectionItem = {
                  PK: `CONNECTION#${connectionId}`,
                  SK: `MERCHANT#${merchantId}`,
                  GSI1PK: `MERCHANT#${merchantId}`,
                  GSI1SK: `CONNECTION#${connectionId}`,
                  connectionId: connectionId,
                  merchantId: merchantId,
                  deviceInfo: deviceInfo,
                  connectionType: 'merchant',
                  timestamp: new Date().toISOString(),
                  ttl: Math.floor(Date.now() / 1000) + (24 * 60 * 60) // 24 hours TTL
                };
                
                // Store in the connections table (not subscriptions table)
                const CONNECTIONS_TABLE = process.env.WEBSOCKET_CONNECTIONS_TABLE || 'WizzUser_websocket_connections_dev';
                await docClient.send(new PutCommand({
                  TableName: CONNECTIONS_TABLE,
                  Item: connectionItem
                }));
                
                console.log(`Stored merchant connection for ${connectionId} -> merchant ${merchantId}`);
                
                // Send registration acknowledgment back to merchant
                const regResponse = {
                  type: 'REGISTRATION_ACK',
                  merchantId: merchantId,
                  connectionId: connectionId,
                  timestamp: new Date().toISOString(),
                  status: 'registered'
                };
                
                const command = new PostToConnectionCommand({
                  ConnectionId: connectionId,
                  Data: JSON.stringify(regResponse)
                });
                
                await apiGatewayClient.send(command);
                console.log(`Registration acknowledgment sent to merchant ${connectionId}`);
                
              } catch (regError) {
                console.error(`Failed to register merchant connection:`, regError);
                
                // Send error response
                try {
                  const errorResponse = {
                    type: 'REGISTRATION_ERROR',
                    error: 'Failed to register connection',
                    timestamp: new Date().toISOString()
                  };
                  
                  const errorCommand = new PostToConnectionCommand({
                    ConnectionId: connectionId,
                    Data: JSON.stringify(errorResponse)
                  });
                  
                  await apiGatewayClient.send(errorCommand);
                } catch (errorSendFail) {
                  console.error(`Failed to send registration error:`, errorSendFail);
                }
              }
              break;

            case 'SUBSCRIBE_ORDERS':
            case 'subscribe_orders':
              const subMerchantId = message.merchant_id || message.merchantId || message.businessId || message.business_id;
              console.log(`Subscribing merchant connection ${connectionId} to orders for merchant ${subMerchantId}`);
              
              // Store order subscription in DynamoDB
              try {
                const orderSubscriptionItem = {
                  subscriptionId: `orders_${connectionId}_${subMerchantId}`, // Primary key
                  connectionId: connectionId,
                  merchantId: subMerchantId,
                  subscriptionType: 'merchant_orders',
                  timestamp: new Date().toISOString(),
                  ttl: Math.floor(Date.now() / 1000) + (24 * 60 * 60) // 24 hours TTL
                };
                
                await docClient.send(new PutCommand({
                  TableName: SUBSCRIPTIONS_TABLE,
                  Item: orderSubscriptionItem
                }));
                
                console.log(`Stored order subscription for merchant ${connectionId} -> ${subMerchantId}`);
                
                // Send subscription acknowledgment back to merchant
                const subResponse = {
                  type: 'ORDER_SUBSCRIPTION_ACK',
                  merchantId: subMerchantId,
                  connectionId: connectionId,
                  timestamp: new Date().toISOString(),
                  status: 'subscribed_to_orders'
                };
                
                const command = new PostToConnectionCommand({
                  ConnectionId: connectionId,
                  Data: JSON.stringify(subResponse)
                });
                
                await apiGatewayClient.send(command);
                console.log(`Order subscription acknowledgment sent to merchant ${connectionId}`);
                
              } catch (subError) {
                console.error(`Failed to subscribe to orders:`, subError);
                
                // Send error response
                try {
                  const errorResponse = {
                    type: 'SUBSCRIPTION_ERROR',
                    error: 'Failed to subscribe to orders',
                    timestamp: new Date().toISOString()
                  };
                  
                  const errorCommand = new PostToConnectionCommand({
                    ConnectionId: connectionId,
                    Data: JSON.stringify(errorResponse)
                  });
                  
                  await apiGatewayClient.send(errorCommand);
                } catch (errorSendFail) {
                  console.error(`Failed to send subscription error:`, errorSendFail);
                }
              }
              break;

            case 'UPDATE_ORDER_STATUS':
            case 'update_order_status':
              const statusOrderId = message.order_id || message.orderId;
              const newStatus = message.status || message.newStatus;
              const statusMerchantId = message.merchant_id || message.merchantId || message.businessId || message.business_id;
              const statusUserId = message.user_id || message.userId || message.customerId;
              
              console.log(`Received order status update: Order ${statusOrderId} -> ${newStatus} from merchant ${statusMerchantId}`);
              
              if (statusOrderId && newStatus && statusMerchantId) {
                try {
                  // Find the customer connection for this order
                  const scanParams = {
                    TableName: SUBSCRIPTIONS_TABLE,
                    FilterExpression: 'subscriptionType = :subType',
                    ExpressionAttributeValues: {
                      ':subType': 'order_tracking'
                    }
                  };
                  
                  const result = await docClient.send(new ScanCommand(scanParams));
                  const orderSubscriptions = (result.Items || []).filter(sub => 
                    sub.orderId === statusOrderId || sub.order_id === statusOrderId
                  );
                  
                  console.log(`Found ${orderSubscriptions.length} order tracking subscriptions for order ${statusOrderId}`);
                  
                  // Create customer notification message
                  const customerNotification = {
                    type: 'ORDER_STATUS_UPDATE',
                    orderId: statusOrderId,
                    status: newStatus,
                    merchantId: statusMerchantId,
                    timestamp: new Date().toISOString()
                  };
                  
                  // Send to all subscribed customers
                  const customerNotifyPromises = orderSubscriptions.map(async (subscription) => {
                    try {
                      const customerConnectionId = subscription.connectionId;
                      console.log(`Sending order status update to customer: ${customerConnectionId}`);
                      
                      const command = new PostToConnectionCommand({
                        ConnectionId: customerConnectionId,
                        Data: JSON.stringify(customerNotification)
                      });
                      
                      await apiGatewayClient.send(command);
                      console.log(`✅ Order status update sent to customer ${customerConnectionId}`);
                      return { success: true, connectionId: customerConnectionId };
                    } catch (sendError) {
                      console.error(`❌ Failed to send order update to ${subscription.connectionId}:`, sendError);
                      
                      // Clean up stale connections
                      if (sendError.name === 'GoneException') {
                        try {
                          await docClient.send(new DeleteCommand({
                            TableName: SUBSCRIPTIONS_TABLE,
                            Key: { subscriptionId: subscription.subscriptionId }
                          }));
                          console.log(`Removed stale order subscription: ${subscription.connectionId}`);
                        } catch (deleteError) {
                          console.error(`Failed to remove stale subscription:`, deleteError);
                        }
                      }
                      return { success: false, connectionId: subscription.connectionId, error: sendError.message };
                    }
                  });
                  
                  const customerResults = await Promise.all(customerNotifyPromises);
                  const customerSuccessCount = customerResults.filter(r => r.success).length;
                  console.log(`📱 Customer notification complete: ${customerSuccessCount}/${orderSubscriptions.length} customers notified`);
                  
                  // Send acknowledgment back to merchant
                  const merchantAck = {
                    type: 'ORDER_STATUS_UPDATE_ACK',
                    orderId: statusOrderId,
                    status: newStatus,
                    merchantId: statusMerchantId,
                    timestamp: new Date().toISOString(),
                    customersNotified: customerSuccessCount,
                    processed: true
                  };
                  
                  const merchantCommand = new PostToConnectionCommand({
                    ConnectionId: connectionId,
                    Data: JSON.stringify(merchantAck)
                  });
                  
                  await apiGatewayClient.send(merchantCommand);
                  console.log(`Order status update acknowledgment sent to merchant ${connectionId}`);
                  
                } catch (statusError) {
                  console.error(`Failed to process order status update:`, statusError);
                  
                  // Send error response to merchant
                  try {
                    const errorResponse = {
                      type: 'ORDER_STATUS_UPDATE_ERROR',
                      orderId: statusOrderId,
                      error: 'Failed to process status update',
                      timestamp: new Date().toISOString()
                    };
                    
                    const errorCommand = new PostToConnectionCommand({
                      ConnectionId: connectionId,
                      Data: JSON.stringify(errorResponse)
                    });
                    
                    await apiGatewayClient.send(errorCommand);
                  } catch (errorSendFail) {
                    console.error(`Failed to send status update error:`, errorSendFail);
                  }
                }
              } else {
                console.error(`Invalid order status update message - missing required fields:`, message);
              }
              break;

            case 'SUBSCRIBE_ORDER_TRACKING':
            case 'subscribe_order_tracking':
              const trackingOrderId = message.order_id || message.orderId;
              const trackingUserId = message.user_id || message.userId;
              console.log(`Subscribing customer connection ${connectionId} to order tracking for order ${trackingOrderId}`);
              
              // Store order tracking subscription in DynamoDB
              try {
                const trackingSubscriptionItem = {
                  subscriptionId: `order_tracking_${connectionId}_${trackingOrderId}`, // Primary key
                  connectionId: connectionId,
                  orderId: trackingOrderId,
                  userId: trackingUserId,
                  subscriptionType: 'order_tracking',
                  timestamp: new Date().toISOString(),
                  ttl: Math.floor(Date.now() / 1000) + (4 * 60 * 60) // 4 hours TTL (order lifetime)
                };
                
                await docClient.send(new PutCommand({
                  TableName: SUBSCRIPTIONS_TABLE,
                  Item: trackingSubscriptionItem
                }));
                
                console.log(`Stored order tracking subscription for customer ${connectionId} -> order ${trackingOrderId}`);
                
                // Send subscription acknowledgment back to customer
                const trackingResponse = {
                  type: 'ORDER_TRACKING_SUBSCRIPTION_ACK',
                  orderId: trackingOrderId,
                  userId: trackingUserId,
                  connectionId: connectionId,
                  timestamp: new Date().toISOString(),
                  status: 'subscribed_to_order_tracking'
                };
                
                const command = new PostToConnectionCommand({
                  ConnectionId: connectionId,
                  Data: JSON.stringify(trackingResponse)
                });
                
                await apiGatewayClient.send(command);
                console.log(`Order tracking subscription acknowledgment sent to customer ${connectionId}`);
                
              } catch (trackingError) {
                console.error(`Failed to subscribe to order tracking:`, trackingError);
                
                // Send error response
                try {
                  const errorResponse = {
                    type: 'ORDER_TRACKING_SUBSCRIPTION_ERROR',
                    orderId: trackingOrderId,
                    error: 'Failed to subscribe to order tracking',
                    timestamp: new Date().toISOString()
                  };
                  
                  const errorCommand = new PostToConnectionCommand({
                    ConnectionId: connectionId,
                    Data: JSON.stringify(errorResponse)
                  });
                  
                  await apiGatewayClient.send(errorCommand);
                } catch (errorSendFail) {
                  console.error(`Failed to send order tracking subscription error:`, errorSendFail);
                }
              }
              break;

            case 'heartbeat':
            case 'ping':
              console.log(`Heartbeat/Ping from connection ${connectionId}`);
              // Send heartbeat response back to client
              try {
                const heartbeatResponse = {
                  type: 'heartbeat_response',
                  timestamp: new Date().toISOString(),
                  connectionId: connectionId
                };
                
                const command = new PostToConnectionCommand({
                  ConnectionId: connectionId,
                  Data: JSON.stringify(heartbeatResponse)
                });
                
                await apiGatewayClient.send(command);
                console.log(`Heartbeat response sent to ${connectionId}`);
              } catch (heartbeatError) {
                console.error(`Failed to send heartbeat response to ${connectionId}:`, heartbeatError);
              }
              break;

            default:
              console.log(`Unknown message type: ${messageType}`);
              // Send a generic acknowledgment for unknown messages
              try {
                const unknownResponse = {
                  type: 'unknown_message_ack',
                  receivedType: messageType,
                  timestamp: new Date().toISOString(),
                  connectionId: connectionId,
                  message: 'Message received but type not recognized'
                };
                
                const command = new PostToConnectionCommand({
                  ConnectionId: connectionId,
                  Data: JSON.stringify(unknownResponse)
                });
                
                await apiGatewayClient.send(command);
                console.log(`Unknown message acknowledgment sent to ${connectionId}`);
              } catch (ackError) {
                console.error(`Failed to send unknown message ack to ${connectionId}:`, ackError);
              }
              break;
          }
    }

    return {
      statusCode: 200,
      body: 'Message received'
    };
    
  } catch (error) {
    console.error('Error handling WebSocket message:', error);
    console.error('Error stack:', error instanceof Error ? error.stack : 'No stack trace');
    console.error('Error type:', typeof error);
    console.error('Error details:', JSON.stringify(error, null, 2));
    
    // Try to send error message back to client if possible
    try {
      const connectionId = event.requestContext?.connectionId;
      const apiId = event.requestContext?.apiId || 'lwk0wf6rpl';
      
      if (connectionId) {
        const apiGatewayClient = new ApiGatewayManagementApiClient({
          endpoint: `https://${apiId}.execute-api.us-east-1.amazonaws.com/dev`
        });
        
        const errorResponse = {
          type: 'error',
          message: 'Internal server error',
          timestamp: new Date().toISOString(),
          connectionId: connectionId
        };
        
        const command = new PostToConnectionCommand({
          ConnectionId: connectionId,
          Data: JSON.stringify(errorResponse)
        });
        
        await apiGatewayClient.send(command);
        console.log('Error response sent to client');
      }
    } catch (sendError) {
      console.error('Failed to send error response to client:', sendError);
    }
    
    return {
      statusCode: 500,
      body: JSON.stringify({ 
        error: 'Failed to process message',
        details: error instanceof Error ? error.message : 'Unknown error'
      })
    };
  }
};